// Predict 1: Console will print "I was born in 1980" (no quotes)

// Predict 2: Console will print "I was born in 1980" (no quotes)

/* Predict 3: Console will print 4 lines.  
    Summing Numbers!
    num1 is: 10
    num2 is: 20
    30
    */